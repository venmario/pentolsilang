package com.ubaya.pentolsilang_160419091

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HistoryCard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.history_card)
    }
}